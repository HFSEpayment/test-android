package com.example.myapplication

import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.myapplication.databinding.ActivityMainBinding
import com.ss.halykepay.data.model.AuthConfig
import com.ss.halykepay.data.BuildType
import com.ss.halykepay.data.model.Invoice
import com.ss.halykepay.HalykEpaySDK

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var halykEpaySdk: HalykEpaySDK

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.test.setOnClickListener {
            openPayment()
        }

        val navView: BottomNavigationView = binding.navView

        val navController = findNavController(R.id.nav_host_fragment_activity_main)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications
            )
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)
    }
    private fun openPayment() {
        println("test")
//        private const val DEBUG_MERCHANT_ID = "67e34d63-102f-4bd1-898e-370781d0074d"
//        private const val DEBUG_MERCHANT_NAME = "UberFlower"
//        private const val DEBUG_CLIENT_ID = "test"
//        private const val DEBUG_CLIENT_SECRET = "yF587AV9Ms94qN2QShFzVR3vFnWkhjbAK3sG"

        val config = AuthConfig(
            merchantID = "67e34d63-102f-4bd1-898e-370781d0074d",
            merchantName = "UberFlower",
            clientID = "test",
            clientSecret = "yF587AV9Ms94qN2QShFzVR3vFnWkhjbAK3sG"
        )
        val invoice = Invoice(
            id = "4984984899848",
            amount = 100.0,
            currency = "KZT",
            accountID = "uuid023001",
            description = "test payment",
            postLink = "https://testmerchant/order/1123",
            backLink = "https://testmerchant/order/1123",
            failurePostLink = "https://testmerchant/order/1123/fail",
            isRecurrent = false,
            homebankToken = "9FZYVXC4PZCSUFBKQ5PZKW",
            isP2P = true,
            isAFT = false,
            isOCT = false,
            cardId = null,
            isP2PPhone = false,
            failureBackLink = "test"
        )

        halykEpaySdk = HalykEpaySDK.instance(
            this,
             config,
            getBuildType()
        ).apply {
            launchEpay(invoice)
        }
    }
    private fun getBuildType(): BuildType {
        return BuildType.DEBUG
    }
}
